import os
import time
import hashlib
from datetime import datetime

# Windows-only libs
import win32file
import win32con
import win32api

import cv2
import pyautogui

# ------------------------
# CONFIG (location unchanged)
# ------------------------
LOG_PATH = r"C:\USB_Security_Logs"
EVENT_LOG = os.path.join(LOG_PATH, "event_log.txt")

HONEYPOT_FILES = ["Secrets.doc", "Confidential.txt"]  # baits
SUSPICIOUS_EXTENSIONS = {".exe", ".bat", ".scr"}
SKIP_EXTENSIONS = {".iso", ".img", ".vhd", ".wim"}  # avoid permission issues
KNOWN_MALWARE_HASHES = {"dummyhash123"}  # replace with real sha256

MOUNT_SETTLE_SECONDS = 3
WRITE_RETRIES = 5
WRITE_RETRY_DELAY = 1.2  # seconds

# ------------------------
# UTIL
# ------------------------
def log_event(msg: str):
    os.makedirs(LOG_PATH, exist_ok=True)
    line = f"{datetime.now()} - {msg}"
    with open(EVENT_LOG, "a", encoding="utf-8", errors="ignore") as f:
        f.write(line + "\n")
    print(line)

def hash_file(filepath):
    sha256_hash = hashlib.sha256()
    with open(filepath, "rb") as f:
        for b in iter(lambda: f.read(4096), b""):
            sha256_hash.update(b)
    return sha256_hash.hexdigest()

def capture_webcam_image():
    try:
        cam = cv2.VideoCapture(0)
        ret, frame = cam.read()
        if ret:
            fn = os.path.join(LOG_PATH, f"webcam_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg")
            cv2.imwrite(fn, frame)
            log_event(f"Webcam image saved: {fn}")
        cam.release()
    except Exception as e:
        log_event(f"Failed to capture webcam image: {e}")

def capture_screenshot():
    try:
        image = pyautogui.screenshot()
        fn = os.path.join(LOG_PATH, f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
        image.save(fn)
        log_event(f"Screenshot saved: {fn}")
    except Exception as e:
        log_event(f"Failed to capture screenshot: {e}")

# ------------------------
# USB DETECTION
# ------------------------
def get_removable_drives():
    drives = win32api.GetLogicalDriveStrings().split('\000')[:-1]
    return [d for d in drives if win32file.GetDriveType(d) == win32con.DRIVE_REMOVABLE]

def wait_for_drive_ready(usb_path, timeout=15):
    """
    Wait until the drive exists and is writable.
    Returns True if writable within timeout, else False.
    """
    deadline = time.time() + timeout
    test_name = os.path.join(usb_path, ".honeypot_write_test.tmp")

    # Initial settle, Windows may still be mounting
    time.sleep(MOUNT_SETTLE_SECONDS)

    while time.time() < deadline:
        try:
            if not os.path.exists(usb_path):
                time.sleep(0.5)
                continue
            # Try writing a tiny file to test writability
            with open(test_name, "w") as f:
                f.write("ok")
            os.remove(test_name)
            return True
        except Exception:
            time.sleep(0.6)
    return False

# ------------------------
# SCAN + HONEYPOT
# ------------------------
def scan_usb(usb_path):
    for root, dirs, files in os.walk(usb_path):
        for name in files:
            ext = os.path.splitext(name)[1].lower()
            if ext in SKIP_EXTENSIONS:
                # Skip problematic system/large images
                continue

            file_path = os.path.join(root, name)
            try:
                # Hidden?
                try:
                    attrs = os.stat(file_path).st_file_attributes
                    if attrs & 2:  # FILE_ATTRIBUTE_HIDDEN
                        log_event(f"Hidden file detected: {file_path}")
                except Exception:
                    pass

                # Suspicious extensions
                if ext in SUSPICIOUS_EXTENSIONS:
                    log_event(f"Suspicious extension detected: {file_path}")

                # Hash check
                h = hash_file(file_path)
                if h in KNOWN_MALWARE_HASHES:
                    log_event(f"Known malware detected (hash match): {file_path}")
            except Exception as e:
                log_event(f"Error scanning {file_path}: {e}")

def deploy_or_rename_honeypots_smart(usb_path):
    """
    Old behavior kept (deploy if missing, rename if present),
    but with robust root->fallback + retries.
    """
    fallback_dir = os.path.join(usb_path, "Honeypot")
    for i, fname in enumerate(HONEYPOT_FILES, start=1):
        root_src = os.path.join(usb_path, fname)
        fallback_src = os.path.join(fallback_dir, fname)

        # If file exists (in root or fallback), rename in-place
        for src in (root_src, fallback_src):
            if os.path.exists(src):
                try:
                    base, _ = os.path.splitext(fname)
                    dst = os.path.join(os.path.dirname(src), f"{base}_{i}.txt")
                    os.rename(src, dst)
                    log_event(f"Honeypot file renamed: {src} -> {dst}")
                    break  # done with this honeypot item
                except Exception as e:
                    log_event(f"Failed to rename honeypot {src}: {e}")
                    # if rename fails, try deploy path next
                    # (no break)

        else:
            # Not found anywhere -> deploy new
            # 1) try root
            deployed = False
            for attempt in range(1, WRITE_RETRIES + 1):
                try:
                    with open(root_src, "w") as f:
                        f.write("Confidential data. Unauthorized access will be reported.")
                    log_event(f"Honeypot file deployed: {root_src}")
                    deployed = True
                    break
                except Exception as e:
                    if attempt < WRITE_RETRIES:
                        time.sleep(WRITE_RETRY_DELAY)
                    else:
                        log_event(f"Root deploy failed for {fname}: {e}")

            if deployed:
                continue

            # 2) fallback to \Honeypot\
            try:
                os.makedirs(fallback_dir, exist_ok=True)
                for attempt in range(1, WRITE_RETRIES + 1):
                    try:
                        with open(fallback_src, "w") as f:
                            f.write("Confidential data. Unauthorized access will be reported.")
                        log_event(f"Honeypot file deployed (fallback): {fallback_src}")
                        deployed = True
                        break
                    except Exception as e:
                        if attempt < WRITE_RETRIES:
                            time.sleep(WRITE_RETRY_DELAY)
                        else:
                            log_event(f"Fallback deploy failed for {fname}: {e}")
            except Exception as e:
                log_event(f"Failed to create fallback dir {fallback_dir}: {e}")

def handle_new_usb(usb):
    log_event(f"New USB detected: {usb}")

    if not wait_for_drive_ready(usb, timeout=20):
        log_event(f"Drive {usb} not ready/writable. Skipping actions.")
        return

    # Only capture after confirmed new USB (prevents false positives at startup)
    capture_webcam_image()
    capture_screenshot()

    scan_usb(usb)
    deploy_or_rename_honeypots_smart(usb)

# ------------------------
# MAIN MONITOR
# ------------------------
def monitor_usb():
    log_event("USB monitoring started...")
    known = set(get_removable_drives())

    while True:
        time.sleep(2)
        try:
            current = set(get_removable_drives())
            new = [d for d in current if d not in known]
            if new:
                for usb in new:
                    handle_new_usb(usb)
            known = current
        except Exception as e:
            # Do not die; keep running
            log_event(f"Monitor loop error: {e}")
            time.sleep(1)

if __name__ == "__main__":
    try:
        monitor_usb()
    except Exception as e:
        # Catch any crash so the window doesn't vanish silently
        log_event(f"FATAL: {e}")
        # Keep console open if double-clicked
        try:
            input("Press Enter to exit...")
        except Exception:
            pass
