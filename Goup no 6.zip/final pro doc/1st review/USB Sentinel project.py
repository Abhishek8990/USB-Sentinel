# USB Device Whitelisting System (Windows) - Advanced Version
# Requirements: pywin32, wmi, opencv-python, pyautogui
# pip install pywin32 wmi opencv-python pyautogui

import wmi
import time
import ctypes
import subprocess
import os
import datetime
import cv2
import pyautogui

# === Configuration ===
WHITELISTED_USB_SERIALS = [
    "1234567890ABCDEF",
    #"0608312208881",
]

ADMIN_MODE = False  # Set to True to enable whitelist update prompt
LOG_FILE = "usb_event_log.txt"
HONEYPOT_FILENAME = "bank_accounts.xlsx"

# === Helper Functions ===
def notify(message):
    ctypes.windll.user32.MessageBoxW(0, message, "USB Security Alert", 1)

def log_event(message):
    timestamp = datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with open(LOG_FILE, "a") as log:
        log.write(f"{timestamp} {message}\n")

def get_connected_usb_serials():
    c = wmi.WMI()
    serials = []
    for usb in c.Win32_DiskDrive():
        if "USB" in usb.InterfaceType:
            serial = usb.SerialNumber
            if serial:
                serials.append(serial.strip())
    return serials

def get_usb_drive_letters():
    c = wmi.WMI()
    drives = []
    for disk in c.Win32_DiskDrive():
        if "USB" in disk.InterfaceType:
            for partition in disk.associators("Win32_DiskDriveToDiskPartition"):
                for logical in partition.associators("Win32_LogicalDiskToPartition"):
                    drives.append(logical.DeviceID)
    return drives

def format_usb_drive(drive_letter):
    try:
        cmd = f"format {drive_letter} /FS:NTFS /Q /Y"
        subprocess.run(cmd, shell=True, check=True)
        log_event(f"Drive {drive_letter} formatted due to unauthorized access.")
    except Exception as e:
        log_event(f"Error formatting drive {drive_letter}: {e}")

def lock_system():
    try:
        subprocess.run("rundll32.exe user32.dll,LockWorkStation", shell=True)
        log_event("System locked due to unauthorized USB.")
    except Exception as e:
        log_event(f"Failed to lock system: {e}")

def capture_webcam_image():
    try:
        cam = cv2.VideoCapture(0)
        ret, frame = cam.read()
        if ret:
            cv2.imwrite("intruder.jpg", frame)
            log_event("Webcam image captured on unauthorized USB access.")
        cam.release()
    except Exception as e:
        log_event(f"Webcam capture failed: {e}")

def take_screenshot():
    try:
        save_path = "C:/Users/Dell/Documents/proof/screenshot.png"
        folder_path = os.path.dirname(save_path)

        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
            print(f"[+] Created folder: {folder_path}")

        screenshot = pyautogui.screenshot()
        screenshot.save(save_path)
        print(f"[+] Screenshot saved at: {save_path}")
        log_event(f"Screenshot taken and saved at: {save_path}")
    except Exception as e:
        print(f"[!] Screenshot failed: {e}")
        log_event(f"Screenshot failed: {e}")




def place_honeypot_file(drive_letter):
    try:
        filepath = os.path.join(drive_letter + "\\", HONEYPOT_FILENAME)
        with open(filepath, "w") as f:
            f.write("Account No\tPassword\n123456\tpass123")
        log_event(f"Honeypot file created on {drive_letter}.")
    except Exception as e:
        log_event(f"Failed to create honeypot file: {e}")

def overview_usb_data(drive_letter):
    try:
        ext_count = {}
        total_size = 0
        file_count = 0
        for root, dirs, files in os.walk(drive_letter + "\\"):
            for file in files:
                file_count += 1
                ext = os.path.splitext(file)[1].lower()
                ext_count[ext] = ext_count.get(ext, 0) + 1
                total_size += os.path.getsize(os.path.join(root, file))

        size_mb = round(total_size / (1024 * 1024), 2)
        log_event(f"USB {drive_letter} contains {file_count} files, size: {size_mb} MB")
        for ext, count in ext_count.items():
            log_event(f"  - {ext}: {count} file(s)")

    except Exception as e:
        log_event(f"Failed to analyze USB content on {drive_letter}: {e}")

# === Main Monitoring Loop ===
print("[+] USB Whitelisting System Started...")
seen_serials = set()

try:
    while True:
        connected_serials = get_connected_usb_serials()
        connected_drives = get_usb_drive_letters()

        for serial in connected_serials:
            if serial not in WHITELISTED_USB_SERIALS:
                if serial not in seen_serials:
                    print(f"[!] Unauthorized USB detected: {serial}")
                    log_event(f"Unauthorized USB detected: {serial}")
                    notify("Unauthorized USB detected! System actions initiated.")

                    for drive in connected_drives:
                        overview_usb_data(drive)
                        place_honeypot_file(drive)

                    capture_webcam_image()
                    take_screenshot()
                    lock_system()

                    for drive in connected_drives:
                        format_usb_drive(drive)

                    seen_serials.add(serial)

            elif serial not in seen_serials:
                print(f"[+] Authorized USB connected: {serial}")
                log_event(f"Authorized USB detected: {serial}")
                for drive in connected_drives:
                    overview_usb_data(drive)
                seen_serials.add(serial)

        time.sleep(5)

except KeyboardInterrupt:
    print("[!] Monitoring stopped by user.")
    log_event("Monitoring manually stopped.")
